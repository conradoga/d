from django.contrib import admin
from Autos.models import Autos,Motocicletas,Camionetas
# Register your models here.
admin.site.register(Autos)
admin.site.register(Camionetas)
admin.site.register(Motocicletas)