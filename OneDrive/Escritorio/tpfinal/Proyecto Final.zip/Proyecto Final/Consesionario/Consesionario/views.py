from django.http import HttpResponse
from django.template import Template,Context
from django.shortcuts import render
from Autos.models import Autos,Motocicletas,Camionetas

def saludo(request):
    return HttpResponse("Saludo de prueba")

def index(request):
    todos = [Autos.objects.all(),
    Motocicletas.objects.all(),
    Camionetas.objects.all()
    ] 
    context = {"todos":todos}
    return render(request,"index.html",context=context)
    

